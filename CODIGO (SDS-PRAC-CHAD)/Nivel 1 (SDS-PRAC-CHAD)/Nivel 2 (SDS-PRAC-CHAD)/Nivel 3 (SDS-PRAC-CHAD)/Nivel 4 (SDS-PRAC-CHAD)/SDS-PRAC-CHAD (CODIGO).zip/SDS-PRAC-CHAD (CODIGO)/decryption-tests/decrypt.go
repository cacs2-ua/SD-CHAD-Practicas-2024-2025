package main

import (
	"encoding/base64"
	"fmt"
	"log"

	"prac/pkg/crypto"
)

func main() {
	// Replace this with the base64 ciphertext obtained from the database (or from client update logs)
	ciphertextBase64 := "wPiMBniZZW+T+7J4TCBvDbxNZpVVlREAEt0dLQW4UFquHtwAe2XI5Jr8Jbcyk8zziVo88pvBY2fV8TGb"

	// Decode the base64 string to get the encrypted data (nonce + ciphertext)
	ciphertext, err := base64.StdEncoding.DecodeString(ciphertextBase64)
	if err != nil {
		log.Fatalf("Error decoding base64: %v", err)
	}

	// Replace these with the actual username and password used during encryption.
	username := "crisCHAD4"
	password := "crisCHAD4"

	// Derive the encryption key from the password and username.
	key, err := crypto.DeriveKey(password, username)
	if err != nil {
		log.Fatalf("Error deriving key: %v", err)
	}

	// Decrypt the data.
	plaintext, err := crypto.Decrypt(ciphertext, key)
	if err != nil {
		log.Fatalf("Error decrypting data: %v", err)
	}

	fmt.Println("Decrypted plaintext:", string(plaintext))
}
